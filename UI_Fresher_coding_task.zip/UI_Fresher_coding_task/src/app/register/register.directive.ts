import { Directive,Input } from '@angular/core';
import { Validator, NG_VALIDATORS, AbstractControl } from '@angular/forms';
@Directive({
  selector: '[appRegister]',
  providers: [{
    provide: NG_VALIDATORS,
    useExisting:RegisterDirective,
    multi: true
 }]
})
export class RegisterDirective implements Validator {

  @Input() appRegister: string
  validate(control: AbstractControl):{[key:string]: any} | null{
      const controlToCompare = control.parent.get(this.appRegister);
      if( controlToCompare && controlToCompare.value !== control.value){
        return { 'notEqual': true};
      }
      return null;

}
}
