import { RegisterDirective } from './register.directive';

describe('RegisterDirective', () => {
  it('should create an instance', () => {
    const directive = new RegisterDirective();
    expect(directive).toBeTruthy();
  });
});
