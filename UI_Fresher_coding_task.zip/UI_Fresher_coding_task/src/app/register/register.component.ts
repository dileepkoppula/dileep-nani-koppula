import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
Registerform:FormGroup;
  oldpassword: any;
  previouspassword: any;
  retypepassword: any;
  userdata: any;
  constructor(private formbuilder:FormBuilder,private router:Router) { }


 saveData:boolean;
  ngOnInit() {
    this.Registerform=this.formbuilder.group({
      "firstname":["",Validators.required],
      "lastname":["",Validators.required],
      "middlename":[""],
      "phonenumber":[""],
      "password":["",[Validators.required,Validators.minLength(6)]],
      "confirmpassword":["",Validators.required],
      "email":["",Validators.required]
     
    })
  }
  changepassword(event){
    console.log(event);
   if(event.key==this.oldpassword){
     alert("enter valid password");
   }
 }
  
  submit(){
    this.Registerform.controls['firstname'].markAsUntouched();
    this.Registerform.controls['lastname'].markAsUntouched();
    this.Registerform.controls['email'].markAsUntouched();
    this.Registerform.controls['password'].markAsUntouched();
    this.Registerform.controls['confirmpassword'].markAsUntouched();
   
    
    let registerdata={
      email:this.Registerform.get('email').value,
      password:this.Registerform.get('password').value,
    }
    
    console.log(registerdata);
    // this.registerlist.push(registerdata);
    localStorage.setItem("reg",JSON.stringify(registerdata));
  
    // console.log(this.Registerform.valid);
    if(this.Registerform.valid){
      alert("Registartion successfully");
      this.router.navigate(['/login'])
    }
    else{
      this.saveData=true;
    }
    
    
  }

  
}
