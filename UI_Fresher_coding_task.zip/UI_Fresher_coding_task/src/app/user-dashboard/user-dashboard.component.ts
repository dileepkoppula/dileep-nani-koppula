import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  constructor(private route:ActivatedRoute,private router:Router) { }
userlist=[];
  ngOnInit() {
    this.userlist=JSON.parse(localStorage.getItem("user"));
    
  }
  data1:object[]=[];
  data2:object[]=[];
  data:any;
    
  add(v){
    this.data1.push(v);
  }
    edit(v){
      this.data2=v;
    }
    delete(v){
      this.data1.splice(v,1)
    }
    

}
