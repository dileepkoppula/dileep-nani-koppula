import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserDashboardComponent } from './user-dashboard.component';
import { RegisterComponent } from '../register/register.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
 import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  imports: [
    CommonModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
     BsDatepickerModule,
     BsDatepickerModule.forRoot()
     
  ],
  declarations: [UserDashboardComponent, RegisterComponent],
  providers: [],
  bootstrap: [UserDashboardComponent]
})
export class UserDashboardModule { }
