import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserDashboardComponent } from './user-dashboard.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { RegisterComponent } from '../register/register.component';





const routes: Routes = [
    {
        path: '',
        component: UserDashboardComponent,
        children: [
          {
            path: '', redirectTo: 'main', pathMatch: 'full'
          },
       {
         path:"register",component:RegisterComponent
       }
        ]
      }
];
@NgModule({
    imports: [RouterModule.forChild(routes),FormsModule,ReactiveFormsModule],
    exports: [RouterModule, FormsModule,ReactiveFormsModule]
})
export class UserDashboardRoutingModule{

}