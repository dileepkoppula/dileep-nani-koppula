import { LoginDirective } from './login.directive';

describe('LoginDirective', () => {
  it('should create an instance', () => {
    const directive = new LoginDirective(this.login);
    expect(directive).toBeTruthy();
  });
});
