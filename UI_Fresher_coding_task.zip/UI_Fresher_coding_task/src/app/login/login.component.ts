import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router ,Routes } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  Loginform:FormGroup;
  validdata:boolean=true;
  registerlist: any;
constructor(private formbuilder:FormBuilder,private router:Router) { }

userid:any;
userpassword;
email: any;
ishidden:boolean=true;
  ngOnInit() {
    this.Loginform=this.formbuilder.group({
    "email":["",Validators.required],
    "password":["",Validators.required]
    });
    this.registerlist=JSON.parse(localStorage.getItem("reg"));
    console.log(this.registerlist);
  }
  userlist=[];
  login(){
    console.log(this.Loginform.value);
   let userData={
userid:this.Loginform.get("email").value,
userpassword:this.Loginform.get("password").value
   }
   this.userlist.push(userData);
   localStorage.setItem("user",JSON.stringify(this.userlist));
   console.log(this.userlist);
   if(userData.userid==this.registerlist.email && userData.userpassword==this.registerlist.password){
    this.router.navigate(['/userdashboard']);
      }
else{
  alert("credentials incorrect")
}
  //  this.router.navigate(["/userdashboard"]);
  }
  
  register(){
  
    this.router.navigate(['/register']);

  }

}

